/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
var showControllersOnly = false;
var seriesFilter = "";
var filtersOnlySampleSeries = true;

/*
 * Add header in statistics table to group metrics by category
 * format
 *
 */
function summaryTableHeader(header) {
    var newRow = header.insertRow(-1);
    newRow.className = "tablesorter-no-sort";
    var cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Requests";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 3;
    cell.innerHTML = "Executions";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 7;
    cell.innerHTML = "Response Times (ms)";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Throughput";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 2;
    cell.innerHTML = "Network (KB/sec)";
    newRow.appendChild(cell);
}

/*
 * Populates the table identified by id parameter with the specified data and
 * format
 *
 */
function createTable(table, info, formatter, defaultSorts, seriesIndex, headerCreator) {
    var tableRef = table[0];

    // Create header and populate it with data.titles array
    var header = tableRef.createTHead();

    // Call callback is available
    if(headerCreator) {
        headerCreator(header);
    }

    var newRow = header.insertRow(-1);
    for (var index = 0; index < info.titles.length; index++) {
        var cell = document.createElement('th');
        cell.innerHTML = info.titles[index];
        newRow.appendChild(cell);
    }

    var tBody;

    // Create overall body if defined
    if(info.overall){
        tBody = document.createElement('tbody');
        tBody.className = "tablesorter-no-sort";
        tableRef.appendChild(tBody);
        var newRow = tBody.insertRow(-1);
        var data = info.overall.data;
        for(var index=0;index < data.length; index++){
            var cell = newRow.insertCell(-1);
            cell.innerHTML = formatter ? formatter(index, data[index]): data[index];
        }
    }

    // Create regular body
    tBody = document.createElement('tbody');
    tableRef.appendChild(tBody);

    var regexp;
    if(seriesFilter) {
        regexp = new RegExp(seriesFilter, 'i');
    }
    // Populate body with data.items array
    for(var index=0; index < info.items.length; index++){
        var item = info.items[index];
        if((!regexp || filtersOnlySampleSeries && !info.supportsControllersDiscrimination || regexp.test(item.data[seriesIndex]))
                &&
                (!showControllersOnly || !info.supportsControllersDiscrimination || item.isController)){
            if(item.data.length > 0) {
                var newRow = tBody.insertRow(-1);
                for(var col=0; col < item.data.length; col++){
                    var cell = newRow.insertCell(-1);
                    cell.innerHTML = formatter ? formatter(col, item.data[col]) : item.data[col];
                }
            }
        }
    }

    // Add support of columns sort
    table.tablesorter({sortList : defaultSorts});
}

$(document).ready(function() {

    // Customize table sorter default options
    $.extend( $.tablesorter.defaults, {
        theme: 'blue',
        cssInfoBlock: "tablesorter-no-sort",
        widthFixed: true,
        widgets: ['zebra']
    });

    var data = {"OkPercent": 100.0, "KoPercent": 0.0};
    var dataset = [
        {
            "label" : "FAIL",
            "data" : data.KoPercent,
            "color" : "#FF6347"
        },
        {
            "label" : "PASS",
            "data" : data.OkPercent,
            "color" : "#9ACD32"
        }];
    $.plot($("#flot-requests-summary"), dataset, {
        series : {
            pie : {
                show : true,
                radius : 1,
                label : {
                    show : true,
                    radius : 3 / 4,
                    formatter : function(label, series) {
                        return '<div style="font-size:8pt;text-align:center;padding:2px;color:white;">'
                            + label
                            + '<br/>'
                            + Math.round10(series.percent, -2)
                            + '%</div>';
                    },
                    background : {
                        opacity : 0.5,
                        color : '#000'
                    }
                }
            }
        },
        legend : {
            show : true
        }
    });

    // Creates APDEX table
    createTable($("#apdexTable"), {"supportsControllersDiscrimination": true, "overall": {"data": [1.0, 500, 1500, "Total"], "isController": false}, "titles": ["Apdex", "T (Toleration threshold)", "F (Frustration threshold)", "Label"], "items": [{"data": [1.0, 500, 1500, "https://localhost:44318/api/Billercategory/GetAllBillercategory"], "isController": false}, {"data": [1.0, 500, 1500, "http://localhost:4200/scripts.js"], "isController": false}, {"data": [1.0, 500, 1500, "http://localhost:4200/assets/assestR/css/animate.css"], "isController": false}, {"data": [1.0, 500, 1500, "https://localhost:44318/api/User/GetUserprofile/965"], "isController": false}, {"data": [1.0, 500, 1500, "http://localhost:4200/assets/assestR/js/jquery.min.js"], "isController": false}, {"data": [1.0, 500, 1500, "https://localhost:44318/api/User/GetUserprofile/964"], "isController": false}, {"data": [1.0, 500, 1500, "https://localhost:44318/api/User/GetUserprofile/963"], "isController": false}, {"data": [1.0, 500, 1500, "https://localhost:44318/api/Login/Loginuser"], "isController": false}, {"data": [1.0, 500, 1500, "http://localhost:4200/assets/assestR/js/roberto.bundle.js"], "isController": false}, {"data": [1.0, 500, 1500, "https://localhost:44318/api/Testimonial"], "isController": false}, {"data": [1.0, 500, 1500, "https://localhost:44318/api/User/UpdateUserProfile"], "isController": false}, {"data": [1.0, 500, 1500, "ChangeName Transaction"], "isController": true}, {"data": [1.0, 500, 1500, "http://localhost:4200/assets/assestR/css/bootstrap-datepicker.min.css"], "isController": false}, {"data": [1.0, 500, 1500, "http://localhost:4200/user/profile"], "isController": false}, {"data": [1.0, 500, 1500, "http://localhost:4200/assets/assestR/style.css"], "isController": false}, {"data": [1.0, 500, 1500, "http://localhost:4200/assets/assestR/js/default-assets/active.js"], "isController": false}, {"data": [1.0, 500, 1500, "http://localhost:4200/assets/assestR/css/nice-select.css"], "isController": false}, {"data": [1.0, 500, 1500, "http://localhost:4200/assets/assestR/css/fonts/ElegantIcons.woff"], "isController": false}, {"data": [1.0, 500, 1500, "http://localhost:4200/assets/assestR/js/bootstrap.min.js"], "isController": false}, {"data": [1.0, 500, 1500, "http://localhost:4200/assets/assestR/css/font-awesome.min.css"], "isController": false}, {"data": [1.0, 500, 1500, "Login Transaction"], "isController": true}, {"data": [1.0, 500, 1500, "http://localhost:4200/main.js"], "isController": false}, {"data": [1.0, 500, 1500, "http://localhost:4200/styles.js"], "isController": false}, {"data": [1.0, 500, 1500, "https://localhost:44318/api/User/Regester"], "isController": false}, {"data": [1.0, 500, 1500, "http://localhost:4200/runtime.js"], "isController": false}, {"data": [1.0, 500, 1500, "http://localhost:4200/assets/assestR/css/style.css"], "isController": false}, {"data": [1.0, 500, 1500, "http://localhost:4200/vendor.js"], "isController": false}, {"data": [1.0, 500, 1500, "http://localhost:4200/assets/assestR/css/default-assets/classy-nav.css"], "isController": false}, {"data": [1.0, 500, 1500, "Testimonial Transaction"], "isController": true}, {"data": [1.0, 500, 1500, "https://localhost:44318/api/SiteSetting/GetAllSitesetting"], "isController": false}, {"data": [1.0, 500, 1500, "Debug Sampler"], "isController": false}, {"data": [1.0, 500, 1500, "Register"], "isController": true}, {"data": [1.0, 500, 1500, "http://localhost:4200/styles.css"], "isController": false}, {"data": [1.0, 500, 1500, "http://localhost:4200/assets/assestR/css/magnific-popup.css"], "isController": false}, {"data": [1.0, 500, 1500, "http://localhost:4200/assets/assestR/css/bootstrap.min.css"], "isController": false}, {"data": [1.0, 500, 1500, "http://localhost:4200/assets/assestR/css/jquery-ui.min.css"], "isController": false}, {"data": [1.0, 500, 1500, "http://localhost:4200/auth/reqester"], "isController": false}, {"data": [1.0, 500, 1500, "http://localhost:4200/assets/assestR/css/owl.carousel.min.css"], "isController": false}, {"data": [1.0, 500, 1500, "http://localhost:4200/assets/assestR/js/popper.min.js"], "isController": false}, {"data": [1.0, 500, 1500, "http://localhost:4200/polyfills.js"], "isController": false}]}, function(index, item){
        switch(index){
            case 0:
                item = item.toFixed(3);
                break;
            case 1:
            case 2:
                item = formatDuration(item);
                break;
        }
        return item;
    }, [[0, 0]], 3);

    // Create statistics table
    createTable($("#statisticsTable"), {"supportsControllersDiscrimination": true, "overall": {"data": ["Total", 243, 0, 0.0, 4.522633744855968, 0, 342, 2.0, 4.0, 6.799999999999983, 40.60000000000002, 111.67279411764706, 11002.185597139245, 61.62710750804227], "isController": false}, "titles": ["Label", "#Samples", "FAIL", "Error %", "Average", "Min", "Max", "Median", "90th pct", "95th pct", "99th pct", "Transactions/s", "Received", "Sent"], "items": [{"data": ["https://localhost:44318/api/Billercategory/GetAllBillercategory", 6, 0, 0.0, 3.5, 3, 4, 3.5, 4.0, 4.0, 4.0, 3.9656311962987445, 3.6751796926635825, 2.366211582947786], "isController": false}, {"data": ["http://localhost:4200/scripts.js", 6, 0, 0.0, 3.5, 2, 5, 3.5, 5.0, 5.0, 5.0, 3.8167938931297707, 1317.571043058206, 1.8562142175572518], "isController": false}, {"data": ["http://localhost:4200/assets/assestR/css/animate.css", 6, 0, 0.0, 1.6666666666666667, 1, 2, 2.0, 2.0, 2.0, 2.0, 3.8289725590299937, 107.71789745532865, 1.9874012843012125], "isController": false}, {"data": ["https://localhost:44318/api/User/GetUserprofile/965", 10, 0, 0.0, 3.3000000000000007, 3, 4, 3.0, 4.0, 4.0, 4.0, 48.78048780487805, 17.006478658536587, 28.53467987804878], "isController": false}, {"data": ["http://localhost:4200/assets/assestR/js/jquery.min.js", 6, 0, 0.0, 1.1666666666666665, 1, 2, 1.0, 2.0, 2.0, 2.0, 3.7383177570093458, 157.18823014018693, 1.894713785046729], "isController": false}, {"data": ["https://localhost:44318/api/User/GetUserprofile/964", 10, 0, 0.0, 3.5, 2, 5, 3.5, 4.9, 5.0, 5.0, 43.66812227074236, 15.147379912663755, 25.54414574235808], "isController": false}, {"data": ["https://localhost:44318/api/User/GetUserprofile/963", 10, 0, 0.0, 3.5, 3, 4, 3.5, 4.0, 4.0, 4.0, 42.918454935622314, 14.88733905579399, 25.105619635193133], "isController": false}, {"data": ["https://localhost:44318/api/Login/Loginuser", 3, 0, 0.0, 4.0, 4, 4, 4.0, 4.0, 4.0, 4.0, 1.996007984031936, 0.7835890718562875, 1.130551397205589], "isController": false}, {"data": ["http://localhost:4200/assets/assestR/js/roberto.bundle.js", 6, 0, 0.0, 1.6666666666666667, 1, 2, 2.0, 2.0, 2.0, 2.0, 3.7429819089207736, 410.03745418746104, 1.9116987679351216], "isController": false}, {"data": ["https://localhost:44318/api/Testimonial", 9, 0, 0.0, 3.888888888888889, 3, 6, 4.0, 6.0, 6.0, 6.0, 6.993006993006993, 0.9560751748251749, 5.668159965034965], "isController": false}, {"data": ["https://localhost:44318/api/User/UpdateUserProfile", 6, 0, 0.0, 5.0, 4, 7, 4.5, 7.0, 7.0, 7.0, 3.7220843672456576, 0.5088787220843672, 3.580325294665012], "isController": false}, {"data": ["ChangeName Transaction", 6, 0, 0.0, 83.16666666666667, 69, 105, 78.5, 105.0, 105.0, 105.0, 3.579952267303103, 14270.142475574285, 64.15421296986874], "isController": true}, {"data": ["http://localhost:4200/assets/assestR/css/bootstrap-datepicker.min.css", 6, 0, 0.0, 1.3333333333333333, 0, 2, 1.5, 2.0, 2.0, 2.0, 3.8363171355498724, 30.441401254795394, 2.0549022937979537], "isController": false}, {"data": ["http://localhost:4200/user/profile", 6, 0, 0.0, 1.5, 1, 2, 1.5, 2.0, 2.0, 2.0, 3.7313432835820897, 4.434614039179104, 2.4523379197761193], "isController": false}, {"data": ["http://localhost:4200/assets/assestR/style.css", 6, 0, 0.0, 1.5, 1, 2, 1.5, 2.0, 2.0, 2.0, 3.73366521468575, 134.06920892968265, 1.9178788114499066], "isController": false}, {"data": ["http://localhost:4200/assets/assestR/js/default-assets/active.js", 6, 0, 0.0, 1.0, 1, 1, 1.0, 1.0, 1.0, 1.0, 3.7476577139287945, 18.6650921299188, 1.9378757417239225], "isController": false}, {"data": ["http://localhost:4200/assets/assestR/css/nice-select.css", 6, 0, 0.0, 1.0, 1, 1, 1.0, 1.0, 1.0, 1.0, 3.8338658146964857, 8.468949680511182, 2.0030451277955272], "isController": false}, {"data": ["http://localhost:4200/assets/assestR/css/fonts/ElegantIcons.woff", 12, 0, 0.0, 1.5, 1, 2, 1.5, 2.0, 2.0, 2.0, 7.609384908053266, 120.08189006024097, 3.996041732720355], "isController": false}, {"data": ["http://localhost:4200/assets/assestR/js/bootstrap.min.js", 6, 0, 0.0, 1.1666666666666665, 1, 2, 1.0, 2.0, 2.0, 2.0, 3.7429819089207736, 102.91189858858391, 1.906215884279476], "isController": false}, {"data": ["http://localhost:4200/assets/assestR/css/font-awesome.min.css", 6, 0, 0.0, 1.0, 1, 1, 1.0, 1.0, 1.0, 1.0, 3.8363171355498724, 58.970263546994886, 2.0249310661764706], "isController": false}, {"data": ["Login Transaction", 3, 0, 0.0, 24.666666666666668, 24, 26, 24.0, 26.0, 26.0, 26.0, 1.969796454366382, 7.1789847340774795, 8.098479563361787], "isController": true}, {"data": ["http://localhost:4200/main.js", 6, 0, 0.0, 3.6666666666666665, 2, 5, 4.0, 5.0, 5.0, 5.0, 3.804692454026633, 1563.1582662888395, 1.8280358275206088], "isController": false}, {"data": ["http://localhost:4200/styles.js", 6, 0, 0.0, 1.8333333333333333, 1, 2, 2.0, 2.0, 2.0, 2.0, 3.814367450731087, 334.1296487603306, 1.851309202161475], "isController": false}, {"data": ["https://localhost:44318/api/User/Regester", 3, 0, 0.0, 9.333333333333334, 5, 18, 5.0, 18.0, 18.0, 18.0, 1.9292604501607717, 0.6669513665594855, 1.3640474276527332], "isController": false}, {"data": ["http://localhost:4200/runtime.js", 6, 0, 0.0, 1.0, 1, 1, 1.0, 1.0, 1.0, 1.0, 3.75, 13.8299560546875, 1.8109130859375], "isController": false}, {"data": ["http://localhost:4200/assets/assestR/css/style.css", 6, 0, 0.0, 1.5, 1, 2, 1.5, 2.0, 2.0, 2.0, 3.8363171355498724, 48.248056865409204, 1.9837206281969308], "isController": false}, {"data": ["http://localhost:4200/vendor.js", 6, 0, 0.0, 19.166666666666664, 9, 31, 19.5, 31.0, 31.0, 31.0, 3.7383177570093458, 9347.908148364486, 1.8052716121495327], "isController": false}, {"data": ["http://localhost:4200/assets/assestR/css/default-assets/classy-nav.css", 6, 0, 0.0, 1.1666666666666665, 1, 2, 1.0, 2.0, 2.0, 2.0, 3.8314176245210727, 29.179014008620687, 2.056019516283525], "isController": false}, {"data": ["Testimonial Transaction", 9, 0, 0.0, 3.888888888888889, 3, 6, 4.0, 6.0, 6.0, 6.0, 6.987577639751553, 0.9553328804347826, 5.663759219720497], "isController": true}, {"data": ["https://localhost:44318/api/SiteSetting/GetAllSitesetting", 24, 0, 0.0, 19.499999999999996, 2, 342, 3.0, 29.0, 265.25, 342.0, 11.310084825636192, 4.056277980678606, 6.3784902214891614], "isController": false}, {"data": ["Debug Sampler", 3, 0, 0.0, 1.0, 0, 2, 1.0, 2.0, 2.0, 2.0, 2.08768267223382, 1.5372194676409185, 0.0], "isController": false}, {"data": ["Register", 3, 0, 0.0, 162.66666666666666, 33, 410, 45.0, 410.0, 410.0, 410.0, 1.4771048744460857, 4.738563977104874, 3.421574963072378], "isController": true}, {"data": ["http://localhost:4200/styles.css", 6, 0, 0.0, 1.3333333333333333, 1, 2, 1.0, 2.0, 2.0, 2.0, 3.73366521468575, 223.75009723086498, 1.866832607342875], "isController": false}, {"data": ["http://localhost:4200/assets/assestR/css/magnific-popup.css", 6, 0, 0.0, 1.3333333333333333, 1, 2, 1.0, 2.0, 2.0, 2.0, 3.8314176245210727, 13.974946120689655, 2.014861709770115], "isController": false}, {"data": ["http://localhost:4200/assets/assestR/css/bootstrap.min.css", 6, 0, 0.0, 2.0, 1, 3, 2.0, 3.0, 3.0, 3.0, 3.826530612244898, 287.1859803491709, 2.0104233099489797], "isController": false}, {"data": ["http://localhost:4200/assets/assestR/css/jquery-ui.min.css", 6, 0, 0.0, 1.5, 1, 3, 1.0, 3.0, 3.0, 3.0, 3.838771593090211, 32.70828334932822, 2.014980206333973], "isController": false}, {"data": ["http://localhost:4200/auth/reqester", 3, 0, 0.0, 16.666666666666668, 2, 45, 3.0, 45.0, 45.0, 45.0, 1.5715034049240442, 3.377811517810372, 1.0098137113672079], "isController": false}, {"data": ["http://localhost:4200/assets/assestR/css/owl.carousel.min.css", 6, 0, 0.0, 1.1666666666666665, 1, 2, 1.0, 2.0, 2.0, 2.0, 3.8314176245210727, 6.461775622605364, 2.0204741379310343], "isController": false}, {"data": ["http://localhost:4200/assets/assestR/js/popper.min.js", 6, 0, 0.0, 1.0, 1, 1, 1.0, 1.0, 1.0, 1.0, 3.740648379052369, 38.621098620635905, 1.8940685395885286], "isController": false}, {"data": ["http://localhost:4200/polyfills.js", 6, 0, 0.0, 2.0, 1, 3, 2.0, 3.0, 3.0, 3.0, 3.75, 563.4027099609375, 1.820068359375], "isController": false}]}, function(index, item){
        switch(index){
            // Errors pct
            case 3:
                item = item.toFixed(2) + '%';
                break;
            // Mean
            case 4:
            // Mean
            case 7:
            // Median
            case 8:
            // Percentile 1
            case 9:
            // Percentile 2
            case 10:
            // Percentile 3
            case 11:
            // Throughput
            case 12:
            // Kbytes/s
            case 13:
            // Sent Kbytes/s
                item = item.toFixed(2);
                break;
        }
        return item;
    }, [[0, 0]], 0, summaryTableHeader);

    // Create error table
    createTable($("#errorsTable"), {"supportsControllersDiscrimination": false, "titles": ["Type of error", "Number of errors", "% in errors", "% in all samples"], "items": []}, function(index, item){
        switch(index){
            case 2:
            case 3:
                item = item.toFixed(2) + '%';
                break;
        }
        return item;
    }, [[1, 1]]);

        // Create top5 errors by sampler
    createTable($("#top5ErrorsBySamplerTable"), {"supportsControllersDiscrimination": false, "overall": {"data": ["Total", 243, 0, "", "", "", "", "", "", "", "", "", ""], "isController": false}, "titles": ["Sample", "#Samples", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors"], "items": [{"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}]}, function(index, item){
        return item;
    }, [[0, 0]], 0);

});
